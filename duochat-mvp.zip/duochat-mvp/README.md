# DuoChat MVP

DuoChat is a responsive, WhatsApp-green private chat prototype for **exactly two authorized accounts**. It can run as a website and can be installed to an Android home screen as a Progressive Web App (PWA). This starter is not yet a native APK.

## Included in this MVP

- Email/password sign-in; no public registration screen.
- Database allowlist for exactly two authorized accounts.
- Real-time one-to-one text chat.
- Presence-based online status. Messages are hidden and sending is disabled while the other user is offline.
- Browser-side AES-GCM encryption before messages are saved to the database.
- Green responsive chat UI and mobile-friendly layout.
- Message timestamps, basic sent indicator, lock/unlock screen.
- Supabase row-level security policies restricting conversation access.

## Important security limitations

The common code is an encryption unlock code, not a replacement for account authentication. Both users still need separate owner-created Supabase accounts so the backend can enforce the two-person allowlist. Anyone who learns the common code and gains access to an authorized account may be able to decrypt messages. This is an MVP, not a production-ready replacement for WhatsApp. The encryption is a simple shared-secret prototype, not a reviewed Signal Protocol implementation. Both people must exchange the same strong common code through a separate trusted channel. Anyone who knows that secret can decrypt messages. It does not provide forward secrecy, identity key verification, encrypted calls, encrypted file attachments, disappearing messages, or encrypted backups. Do not use it for highly sensitive conversations until the design is reviewed and upgraded.

The PWA works on Android through a browser install. Native Android APK packaging, audio/video calls, media sharing, read receipts, push notifications, key rotation, and a professionally reviewed end-to-end encryption protocol are future work.

## 1. Create the Supabase backend

1. Go to https://supabase.com and create a project.
2. Open **Project Settings → API** and copy the Project URL and publishable/anon key. Do not put a service-role key in the app.
3. Open **SQL Editor**, paste the contents of `supabase.sql`, and run it. The SQL creates the tables and row-level security policies.
4. In **Authentication → Users**, create exactly two users with email and password. Keep public sign-ups disabled.
5. Copy each user's UUID from the users table.
6. In SQL Editor, replace the sample UUIDs at the bottom of `supabase.sql` with the two real UUIDs and the display names, then run only the final `insert into public.authorized_users ...` statement. If you already ran the sample comment, note that the commented statement does not execute automatically.
7. Confirm there are exactly two rows in `public.authorized_users`.

Never share the Supabase service-role key. Keep only the publishable/anon key in the frontend environment; RLS is what protects data.

## 2. Run locally

Install Node.js 20 or newer, then in this folder:

```bash
cp .env.example .env
```

Edit `.env` and set:

```env
VITE_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY
```

Then run:

```bash
npm install
npm run dev
```

Open the local URL shown by Vite. Sign in using one of the two accounts created in Supabase. On both devices, enter the same strong common access/encryption code (at least 16 characters; a longer randomly generated phrase is better). Do not send the code through DuoChat itself. The app only displays conversation content and enables sending while the other account is detected online. Messages are still stored encrypted in Supabase, but the UI hides them whenever the partner is offline.

## 3. Deploy website and install on Android

1. Push this folder to a private Git repository or upload it to a trusted hosting service such as Vercel or Netlify.
2. Set `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` in the hosting provider's environment settings.
3. Deploy the site over HTTPS. Build command: `npm run build`; output folder: `dist`.
4. Open the deployed HTTPS website in Chrome on Android.
5. Open the browser menu and choose **Install app** or **Add to Home screen** (wording varies).

A public URL does not mean public chat access: only the two allowlisted accounts should be able to load the conversation. Still, use a non-public/unlisted URL if preferred, and test with an unauthorized account.

## 4. Basic test checklist

- Sign in with account 1 on one device and account 2 on another.
- Enter the same common access/encryption code on both devices.
- Verify the other account shows Online when connected and Offline when disconnected.
- Verify the conversation content is hidden and sending disabled while the other account is offline.
- Send a message from each side and confirm it appears in real time.
- Enter a different secret on one device and verify the message cannot be decrypted.
- Create a third test auth account but do not add it to `authorized_users`; verify it cannot access the conversation.
- Verify unauthenticated users cannot query `messages`.
- Check Supabase logs and ensure no plaintext message body is stored in `messages`.

## Project structure

- `src/main.jsx` — app UI, Supabase auth, real-time messaging, client-side encryption.
- `src/style.css` — responsive WhatsApp-green inspired styling.
- `supabase.sql` — database tables and access policies.
- `manifest.webmanifest` — installable PWA metadata.
- `.env.example` — required frontend environment variables.
