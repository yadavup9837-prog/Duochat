import React, { useEffect, useMemo, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { createClient } from '@supabase/supabase-js';
import './style.css';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
const supabase = supabaseUrl && supabaseAnonKey ? createClient(supabaseUrl, supabaseAnonKey) : null;

function bytesToBase64(bytes) {
  let binary = ''; for (const b of bytes) binary += String.fromCharCode(b); return btoa(binary);
}
function base64ToBytes(text) {
  return Uint8Array.from(atob(text), c => c.charCodeAt(0));
}
async function deriveKey(secret) {
  const material = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey({ name: 'PBKDF2', salt: new TextEncoder().encode('DuoChat-MVP-v1-shared-salt'), iterations: 310000, hash: 'SHA-256' }, material, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
}
async function encryptMessage(text, key) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const encrypted = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, new TextEncoder().encode(text));
  return { ciphertext: bytesToBase64(new Uint8Array(encrypted)), iv: bytesToBase64(iv) };
}
async function decryptMessage(row, key) {
  try {
    const decrypted = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: base64ToBytes(row.iv) }, key, base64ToBytes(row.ciphertext));
    return new TextDecoder().decode(decrypted);
  } catch { return '🔒 Unable to decrypt — check that both users entered the same shared secret.'; }
}
function timeLabel(date) { return new Date(date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); }

function App() {
  const [session, setSession] = useState(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [loading, setLoading] = useState(false);
  const [profile, setProfile] = useState(null);
  const [partner, setPartner] = useState(null);
  const [partnerOnline, setPartnerOnline] = useState(false);
  const [secret, setSecret] = useState('');
  const [key, setKey] = useState(null);
  const [messages, setMessages] = useState([]);
  const [draft, setDraft] = useState('');
  const [status, setStatus] = useState('');
  const endRef = useRef(null);

  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, nextSession) => setSession(nextSession));
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    let cancelled = false;
    async function loadProfiles() {
      if (!session || !supabase) { setProfile(null); setPartner(null); setMessages([]); return; }
      const { data, error } = await supabase.from('authorized_users').select('user_id, display_name');
      if (cancelled) return;
      if (error) { setStatus('Setup needed: run the SQL in README.md and authorize exactly two users.'); return; }
      const mine = data.find(u => u.user_id === session.user.id);
      const other = data.find(u => u.user_id !== session.user.id);
      if (!mine || !other || data.length !== 2) {
        setStatus('This account is not one of the two authorized users. Ask the owner to configure the two accounts.');
        setProfile(null); setPartner(null); return;
      }
      setProfile(mine); setPartner(other); setStatus('');
    }
    loadProfiles(); return () => { cancelled = true; };
  }, [session]);

  useEffect(() => {
    if (!session || !profile || !partner || !supabase) { setPartnerOnline(false); return; }
    let alive = true;
    const presenceChannel = supabase.channel('duochat-presence', { config: { presence: { key: session.user.id } } });
    const refreshPresence = () => {
      const state = presenceChannel.presenceState();
      const online = Object.prototype.hasOwnProperty.call(state, partner.user_id);
      if (alive) setPartnerOnline(online);
    };
    presenceChannel.on('presence', { event: 'sync' }, refreshPresence)
      .on('presence', { event: 'join' }, refreshPresence)
      .on('presence', { event: 'leave' }, refreshPresence)
      .subscribe(async (state) => {
        if (state === 'SUBSCRIBED') {
          await presenceChannel.track({ user_id: session.user.id, online_at: new Date().toISOString() });
          refreshPresence();
        }
      });
    return () => { alive = false; supabase.removeChannel(presenceChannel); setPartnerOnline(false); };
  }, [session, profile, partner]);

  useEffect(() => {
    let channel;
    let active = true;
    async function loadMessages() {
      // Online-only mode: never display conversation content while the other person is offline.
      if (!session || !profile || !partner || !key || !supabase || !partnerOnline) { setMessages([]); return; }
      const { data, error } = await supabase.from('messages').select('*').or(`and(sender_id.eq.${session.user.id},recipient_id.eq.${partner.user_id}),and(sender_id.eq.${partner.user_id},recipient_id.eq.${session.user.id})`).order('created_at', { ascending: true }).limit(500);
      if (error) { setStatus('Could not load messages. Check the database policies.'); return; }
      const decoded = await Promise.all((data || []).map(async row => ({ ...row, text: await decryptMessage(row, key) })));
      if (active) setMessages(decoded);
      channel = supabase.channel('duochat-private-messages')
        .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, async payload => {
          const row = payload.new;
          if (![session.user.id, partner.user_id].includes(row.sender_id) || ![session.user.id, partner.user_id].includes(row.recipient_id)) return;
          const decodedRow = { ...row, text: await decryptMessage(row, key) };
          setMessages(current => current.some(m => m.id === row.id) ? current : [...current, decodedRow].sort((a,b) => new Date(a.created_at)-new Date(b.created_at)));
        }).subscribe();
    }
    loadMessages();
    return () => { active = false; if (channel && supabase) supabase.removeChannel(channel); };
  }, [session, profile, partner, key, partnerOnline]);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  async function login(e) {
    e.preventDefault(); if (!supabase) return;
    setLoading(true); setLoginError('');
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
    if (error) setLoginError(error.message);
    setLoading(false);
  }
  async function unlock(e) {
    e.preventDefault();
    if (secret.trim().length < 16) { setStatus('Use a shared code of at least 16 characters.'); return; }
    try { const derived = await deriveKey(secret); setKey(derived); setStatus('Encrypted chat unlocked on this device.'); }
    catch { setStatus('Could not unlock encrypted chat in this browser.'); }
  }
  async function sendMessage(e) {
    e.preventDefault();
    const text = draft.trim();
    if (!text || !key || !profile || !partner || !supabase) return;
    if (!partnerOnline) { setStatus('Message not sent: the other person is offline.'); return; }
    setDraft(''); setStatus('Sending…');
    const encrypted = await encryptMessage(text, key);
    const { data, error } = await supabase.from('messages').insert({ sender_id: profile.user_id, recipient_id: partner.user_id, ciphertext: encrypted.ciphertext, iv: encrypted.iv }).select().single();
    if (error) { setDraft(text); setStatus('Message not sent. Check connection and permissions.'); return; }
    const row = { ...data, text };
    setMessages(current => current.some(m => m.id === row.id) ? current : [...current, row]);
    setStatus('');
  }
  async function logout() { setKey(null); setSecret(''); await supabase?.auth.signOut(); }

  if (!supabase) return <main className="setup-screen"><div className="setup-card"><div className="logo-mark">D</div><h1>DuoChat</h1><p>Private messaging for two people.</p><div className="notice error">Supabase configuration missing. Copy <code>.env.example</code> to <code>.env</code> and add your project URL and anon key. See README.md.</div></div></main>;

  if (!session) return <main className="login-screen"><div className="login-card"><div className="logo-mark">D</div><h1>DuoChat</h1><p className="subheading">A private space for two.</p><form onSubmit={login} className="login-form"><label>Email address<input type="email" value={email} onChange={e=>setEmail(e.target.value)} required autoComplete="username" placeholder="you@example.com" /></label><label>Password<input type="password" value={password} onChange={e=>setPassword(e.target.value)} required autoComplete="current-password" placeholder="Your password" /></label>{loginError && <div className="notice error">{loginError}</div>}<button className="primary-btn" disabled={loading}>{loading ? 'Signing in…' : 'Sign in'}</button></form><p className="small-note">Accounts are created by the owner only. There is no public sign-up.</p></div></main>;

  if (!profile || !partner) return <main className="setup-screen"><div className="setup-card"><div className="logo-mark">D</div><h1>DuoChat</h1><p>{status || 'Checking authorized accounts…'}</p><button className="secondary-btn" onClick={logout}>Sign out</button></div></main>;

  if (!key) return <main className="setup-screen"><div className="setup-card"><div className="logo-mark">🔐</div><h1>Unlock private chat</h1><p>Both people must enter the same common access/encryption code. Share it privately outside this app; it is never sent to the server.</p><form onSubmit={unlock} className="login-form"><label>Common access code<input type="password" value={secret} onChange={e=>setSecret(e.target.value)} required minLength={16} autoComplete="off" placeholder="At least 16 characters" /></label><button className="primary-btn">Unlock chat</button></form><div className="notice">The same code unlocks encryption on both devices. Use a long, random code and share it privately. This MVP encryption has not been independently audited.</div><button className="text-btn" onClick={logout}>Sign out</button></div></main>;

  return <main className="app-shell"><header className="topbar"><div className="brand"><div className="mini-logo">D</div><div><strong>DuoChat</strong><span>Private chat · End-to-end encrypted MVP</span></div></div><button className="icon-btn" title="Lock chat" onClick={()=>{setKey(null);setSecret('');setMessages([])}}>🔒</button></header><section className="chat-panel"><div className="chat-header"><div className="avatar">{(partner.display_name || '?').slice(0,1).toUpperCase()}</div><div className="contact"><strong>{partner.display_name}</strong><span>{partnerOnline ? <><i className="online-dot"/> Online now · messages enabled</> : <>Offline · messages hidden and sending disabled</>}</span></div><div className="secure-pill">🔐 Encrypted</div></div><div className="chat-background"><div className="privacy-banner">🔒 Messages are encrypted on your device before they are sent.</div>{!partnerOnline ? <div className="empty-state"><div className="empty-icon">🌙</div><strong>{partner.display_name} is offline</strong><p>Chat messages are hidden. You can send messages only while they are online.</p></div> : messages.length === 0 ? <div className="empty-state"><div className="empty-icon">💬</div><strong>Your private conversation starts here</strong><p>Send a message to begin chatting.</p></div> : messages.map(m => <div key={m.id} className={`message-row ${m.sender_id === profile.user_id ? 'mine' : 'theirs'}`}><div className="bubble"><div className="message-text">{m.text}</div><div className="message-meta">{timeLabel(m.created_at)} {m.sender_id === profile.user_id && <span aria-label="sent">✓</span>}</div></div></div>)}<div ref={endRef}/></div><form className="composer" onSubmit={sendMessage}><div className="composer-lock">🔒</div><textarea rows="1" value={draft} onChange={e=>setDraft(e.target.value)} placeholder={partnerOnline ? 'Type a message' : 'They are offline'} aria-label="Message" disabled={!partnerOnline} onKeyDown={e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();sendMessage(e)}}}/><button className="send-btn" disabled={!draft.trim() || !partnerOnline} aria-label="Send message">➤</button></form>{status && <div className="status-line">{status}</div>}<footer className="chat-footer">Signed in as {profile.display_name} <button className="text-btn" onClick={logout}>Sign out</button></footer></section></main>;
}

createRoot(document.getElementById('root')).render(<App />);
