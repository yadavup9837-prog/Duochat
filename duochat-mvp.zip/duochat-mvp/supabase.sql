-- DuoChat MVP database setup for Supabase.
-- Create the TWO auth users first in Supabase Dashboard > Authentication > Users.
-- Replace the two UUIDs and names in the INSERT statement below.

create extension if not exists pgcrypto;

create table if not exists public.authorized_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null check (length(display_name) between 1 and 60),
  created_at timestamptz not null default now()
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references auth.users(id) on delete cascade,
  recipient_id uuid not null references auth.users(id) on delete cascade,
  ciphertext text not null,
  iv text not null,
  created_at timestamptz not null default now(),
  constraint different_users check (sender_id <> recipient_id),
  constraint ciphertext_size check (length(ciphertext) <= 20000)
);

create index if not exists messages_conversation_time_idx
  on public.messages (created_at asc);

alter table public.authorized_users enable row level security;
alter table public.messages enable row level security;

-- SECURITY DEFINER avoids recursive RLS checks on authorized_users.
create or replace function public.is_duochat_authorized(check_user uuid)
returns boolean
language sql stable security definer
set search_path = ''
set row_security = off
as $$
  select exists (select 1 from public.authorized_users au where au.user_id = check_user);
$$;
revoke all on function public.is_duochat_authorized(uuid) from public;
grant execute on function public.is_duochat_authorized(uuid) to authenticated;

drop policy if exists "two users can see authorized profiles" on public.authorized_users;
create policy "two users can see authorized profiles"
  on public.authorized_users for select to authenticated
  using (public.is_duochat_authorized(auth.uid()));

-- Do not grant authenticated users INSERT/UPDATE/DELETE on authorized_users.
revoke insert, update, delete on public.authorized_users from anon, authenticated;
grant select on public.authorized_users to authenticated;

drop policy if exists "authorized users can read their conversation" on public.messages;
create policy "authorized users can read their conversation"
  on public.messages for select to authenticated
  using (
    public.is_duochat_authorized(auth.uid())
    and (sender_id = auth.uid() or recipient_id = auth.uid())
  );

drop policy if exists "authorized users can send only to the other user" on public.messages;
create policy "authorized users can send only to the other user"
  on public.messages for insert to authenticated
  with check (
    sender_id = auth.uid()
    and sender_id <> recipient_id
    and public.is_duochat_authorized(sender_id)
    and public.is_duochat_authorized(recipient_id)
  );

revoke all on public.messages from anon;
grant select, insert on public.messages to authenticated;

-- Enable realtime delivery. If this reports that messages is already in the publication,
-- ignore that duplicate-publication message.
alter publication supabase_realtime add table public.messages;

-- After creating exactly two users in Authentication > Users, run this with real UUIDs:
-- insert into public.authorized_users (user_id, display_name) values
-- ('00000000-0000-0000-0000-000000000001', 'Person One'),
-- ('00000000-0000-0000-0000-000000000002', 'Person Two');
